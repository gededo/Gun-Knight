using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Guns : MonoBehaviour
{
    public float GunDamage;

    void Start()
    {
        
    }

    void Update()
    {
        
    }
}
