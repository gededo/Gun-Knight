using JetBrains.Annotations;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pistol : Guns
{
    void Awake()
    {
        GunDamage = 3f;
    }

    void Update()
    {
        
    }
}
