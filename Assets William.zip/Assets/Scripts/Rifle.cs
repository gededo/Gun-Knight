using JetBrains.Annotations;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Rifle : Guns
{
    void Awake()
    {
        GunDamage = 6f;
    }

    void Update()
    {

    }
}
